package bil;

import java.util.ArrayList;

public class Garage {

    ArrayList<Bil> bilListe = new ArrayList<>();

    public Garage() {

    }

    // Min metode til at tilføje biler til garagen 
    public void tilføjBil(Bil bilAtTilføje) {

        bilListe.add(bilAtTilføje);

        //    
    }

    public int samletAfgift() {
        int samletAfgift = 0;
// for each loop 
        for (Bil cBil : bilListe) {
            samletAfgift += cBil.beregnGrønEjerafgift();
        }
        return samletAfgift;
    }

    public ArrayList<Bil> getBilListe() {
        return bilListe;
    }

    public void printAlleBiler() {
        for (Bil cBil : bilListe) {
             System.out.println(cBil.toString() + "\n");
        }
    }
    
    
    
    public void setBilListe(ArrayList<Bil> bilListe) {
        this.bilListe = bilListe;
    }

}
