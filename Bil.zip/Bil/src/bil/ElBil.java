package bil;

//fordi jeg extender bil kan jeg lave en constructor med mine ElBil variabler + Bil 
public class ElBil extends Bil {

    private double batteriKapacitetKWh;
    private double maxKm;
    private double whPrKm;

    public ElBil(double batteriKapacitetKWh, double maxKm, double whPrKm, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.batteriKapacitetKWh = batteriKapacitetKWh;
        this.maxKm = maxKm;
        this.whPrKm = whPrKm;
    }

    
    
    public double beregnGrønEjerafgift() {
        double grønEjerafgift = 0;
        double kmPrL = (100/(whPrKm)/91.25);
        
        if (kmPrL >= 20 && kmPrL <= 50) {
            grønEjerafgift = 330;
        } else if (kmPrL >= 15 && kmPrL <= 20) {
            grønEjerafgift = 1050;
        } else if (kmPrL >= 10 && kmPrL <= 15) {
            grønEjerafgift = 2340;
        } else if (kmPrL >= 5 && kmPrL <= 10) {
            grønEjerafgift = 5500;
        } else if (kmPrL <= 5) {
            grønEjerafgift = 10470;

        }
        return grønEjerafgift;
    }

    public String toString() {
         String specifikationer = "regNr " + super.getRegNr() + "\n" + "mærke " + super.getMærke() + "\n"
                + "model " + super.getModel() + "\n" + "årgang " + super.getÅrgang() + "\n"
                + "døre " + super.getAntalDøre() + "\n" + "maxKm" + getMaxKm() + "\n" + "whPrKm: " 
                + getWhPrKm();
               
        return specifikationer;
    
}
    
    
    public double getBatteriKapacitetKWh() {
        return batteriKapacitetKWh;
    }

    public void setBatteriKapacitetKWh(double batteriKapacitetKWh) {
        this.batteriKapacitetKWh = batteriKapacitetKWh;
    }

    public double getMaxKm() {
        return maxKm;
    }

    public void setMaxKm(double maxKm) {
        this.maxKm = maxKm;
    }

    public double getWhPrKm() {
        return whPrKm;
    }

    public void setWhPrKm(double whPrKm) {
        this.whPrKm = whPrKm;
    }

    public String getRegNr() {
        return regNr;
    }

    public void setRegNr(String regNr) {
        this.regNr = regNr;
    }

    public String getMærke() {
        return mærke;
    }

    public void setMærke(String mærke) {
        this.mærke = mærke;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getÅrgang() {
        return årgang;
    }

    public void setÅrgang(int årgang) {
        this.årgang = årgang;
    }

    public int getAntalDøre() {
        return antalDøre;
    }

    public void setAntalDøre(int antalDøre) {
        this.antalDøre = antalDøre;
    }
    
}
