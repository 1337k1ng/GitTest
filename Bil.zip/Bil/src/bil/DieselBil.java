package bil;

public class DieselBil extends Bil {

    private boolean harPartikelFilter;
    private double kmPrL;

    public DieselBil(boolean harPartikelFilter, double kmPrL, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.harPartikelFilter = harPartikelFilter;
        this.kmPrL = kmPrL;
    }

    double beregnGrønEjerafgift() {
        double grønEjerafgift = 0;

        if (kmPrL >= 20 && kmPrL <= 50) {
            grønEjerafgift = 330 + 130;
        } else if (kmPrL >= 15 && kmPrL <= 20) {
            grønEjerafgift = 1050 + 1390;
        } else if (kmPrL >= 10 && kmPrL <= 15) {
            grønEjerafgift = 2340 + 1850;
        } else if (kmPrL >= 5 && kmPrL <= 10) {
            grønEjerafgift = 5500 + 2770;
        } else if (kmPrL <= 5) {
            grønEjerafgift = 10470 + 15250;

        }
        // Her skriver jeg (!) som betyder "omvendt" af det jeg skriver. 
        // (+=) betyder at jeg bruger det udtryk jeg har på venstre side af lighedstegnet igen på den anden side
        if (!harPartikelFilter) {
            grønEjerafgift += 1000;
        }
        return grønEjerafgift;
    }

    public boolean harPartikelFilter() {
        return harPartikelFilter;
    }

    public void setHarPartikelFilter(boolean harPartikelFilter) {
        this.harPartikelFilter = harPartikelFilter;
    }

    public double getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(double kmPrL) {
        this.kmPrL = kmPrL;
    }

    public String getRegNr() {
        return regNr;
    }

    public void setRegNr(String regNr) {
        this.regNr = regNr;
    }

    public String getMærke() {
        return mærke;
    }

    public void setMærke(String mærke) {
        this.mærke = mærke;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getÅrgang() {
        return årgang;
    }

    public void setÅrgang(int årgang) {
        this.årgang = årgang;
    }

    public int getAntalDøre() {
        return antalDøre;
    }

    public void setAntalDøre(int antalDøre) {
        this.antalDøre = antalDøre;
    }

    public String toString() {
        String specifikationer = "regNr " + super.getRegNr() + "\n" + "mærke " + super.getMærke() + "\n"
                + "model " + super.getModel() + "\n" + "årgang " + super.getÅrgang() + "\n"
                + "døre " + super.getAntalDøre() + "\n" + "harPartikelFilter " + harPartikelFilter() + "\n" 
                + "kmPrL: " + getKmPrL();

        return specifikationer;
    }

}
