package bil;

public class Main {

    public static void main(String[] args) {
        // Jeg laver en "BenzinBil" og bruger informationerne fra Bil (ctrl + space)
        Bil benzinBil1 = new BenzinBil(95, 17, "AU93156", "Audi", "R8", 2008, 5);
        Garage madsGarage = new Garage();

        //Jeg laver en "DieselBil"
        Bil dieselBil1 = new DieselBil(false, 25, "AK81", "BrianBMW", "AmagersSkydeservice", 2005, 5);

        //Jeg laver en "ElBil" 
        Bil elBil1 = new ElBil(80, 450, 5, "Dybvad2900", "Tesla", "x", 2018, 5);
        
        
        //Her bruger jeg 2 forskellige metoder til tilføjelse af biler til madsGarage. 
        madsGarage.tilføjBil(elBil1);
        madsGarage.tilføjBil(dieselBil1);
        madsGarage.tilføjBil(benzinBil1);
        
        madsGarage.printAlleBiler();
        System.out.println("Samlet grøn afgift i garagen: " + madsGarage.samletAfgift());
        
        
       /* madsGarage.getBilListe().add(elBil1);
        madsGarage.getBilListe().add(dieselBil1);
        madsGarage.getBilListe().add(benzinBil1);
         */
        /**System.out.println(benzinBil1.toString());
        System.out.println(benzinBil1.beregnGrønEjerafgift());
        System.out.println("\n");
        System.out.println(dieselBil1.toString());
        System.out.println(dieselBil1.beregnGrønEjerafgift());
        System.out.println("\n");
        System.out.println(elBil1.toString());
        System.out.println(elBil1.beregnGrønEjerafgift()); **/
    }

}
