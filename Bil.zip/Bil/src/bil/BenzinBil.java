package bil;

public class BenzinBil extends Bil {

    private int oktantal;
    private double kmPrL;

    public BenzinBil(int oktantal, double kmPrL, String regNr, String mærke, String model, int årgang, int antalDøre) {
        super(regNr, mærke, model, årgang, antalDøre);
        this.oktantal = oktantal;
        this.kmPrL = kmPrL;
    }

    public int getOktantal() {
        return oktantal;
    }

    public void setOktantal(int oktantal) {
        this.oktantal = oktantal;
    }

    public double getKmPrL() {
        return kmPrL;
    }

    public void setKmPrL(double kmPrL) {
        this.kmPrL = kmPrL;
    }
// Super fordi den henvender sig til Bil klassen"parent klassen"  og ikke specifikt til BenzinBil klassen. 
// String toString så vi ikke får positionen på informationer i programmet   

    public String toString() {
        String specifikationer = "regNr " + super.getRegNr() + "\n" + "mærke " + super.getMærke() + "\n"
                + "model " + super.getModel() + "\n" + "årgang " + super.getÅrgang() + "\n"
                + "døre " + super.getAntalDøre() + "\n" + "oktantal" + getOktantal() + "\n" + "kmPrL: " 
                + getKmPrL();
        // "getOktantal" fordi det kun er noget der ligger inde i denne klasse        
        return specifikationer;
    }

    public double beregnGrønEjerafgift() {
        double grønEjerafgift = 0;

        if (kmPrL >= 20 && kmPrL <= 50) {
            grønEjerafgift = 330;
        } else if (kmPrL >= 15 && kmPrL <= 20) {
            grønEjerafgift = 1050;
        } else if (kmPrL >= 10 && kmPrL <= 15) {
            grønEjerafgift = 2340;
        } else if (kmPrL >= 5 && kmPrL <= 10) {
            grønEjerafgift = 5500;
        } else if (kmPrL <= 5) {
            grønEjerafgift = 10470;

        }
        return grønEjerafgift;
    }
}
